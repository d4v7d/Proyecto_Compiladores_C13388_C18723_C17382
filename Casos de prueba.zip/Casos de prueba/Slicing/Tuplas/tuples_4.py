tuple = ()

print(tuple)