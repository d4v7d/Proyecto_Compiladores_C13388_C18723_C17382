# Basado en: https://www.geeksforgeeks.org/python/python-program-to-print-the-fibonacci-sequence/

def fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(9))